export const STORAGE_LAST_ROOM_ID = "last_room_id";
export const STORAGE_USERNAME = "username";
export const STORAGE_USER_ID = "user_id";
