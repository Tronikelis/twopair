export const VIDEO_ATTR_ID = "__twopair-id";
export const VIDEO_ATTR_IS_SYNCING = "__twopair-syncing";
export const SYNC_MARGIN = 1;
export const VIDEO_EVENTS_LISTEN = ["seeking", "seeked", "play", "pause"];
